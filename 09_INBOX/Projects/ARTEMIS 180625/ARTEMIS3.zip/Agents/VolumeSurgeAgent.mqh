//+------------------------------------------------------------------+
//| VolumeSurgeAgent.mqh - Volume Surge Trading Agent                |
//| Versão Atualizada 2025.06.09                                     |
//+------------------------------------------------------------------+
#property copyright "Copyright 2024, MetaQuotes Ltd."
#property link      "https://www.mql5.com"
#property version   "1.02"
#property strict

#include "AgentBase.mqh"

class VolumeSurgeAgent : public AgentBase
{
private:
   int m_lookback_period;
   double m_volume_threshold;
   double m_volume_ma;
   int m_lookback;
   double m_quantum_state;
   double m_previous_volume;
   double m_quantum_coherence;
   
public:
   VolumeSurgeAgent(string symbol, QuantumMarketPhysics* physics = NULL) : 
      AgentBase(symbol, physics, 10)  // Corrigido para usar valor inteiro válido
   {
      m_volume_threshold = 2.0;
      m_lookback = 20;
      m_volume_ma = 0.0;
      m_quantum_state = 0.0;
      m_previous_volume = 0.0;
      m_quantum_coherence = 1.0;
   }
   
   void Update()
   {
      AgentBase::Update();
      
      double volumes[];
      if(CopyTickVolume(m_symbol, m_timeframe, 1, m_lookback_period + 1, volumes) <= 0)
      {
         Print("Erro ao copiar volumes: ", GetLastError());
         return;
      }
      
      ArraySetAsSeries(volumes, true);
      
      double current_volume = volumes[0];
      double avg_volume = 0;
      int count = 0;
      
      for(int i = 1; i < ArraySize(volumes); i++) 
      {
         if(volumes[i] > 0)
         {
            avg_volume += volumes[i];
            count++;
         }
      }
      
      if(count > 0) 
      {
         avg_volume /= count;
         double volume_ratio = (avg_volume > 0) ? (current_volume - avg_volume) / avg_volume : 0;
         m_confidence = MathTanh(volume_ratio);
      }
   }
   
   double GetSignal()
   {
      if(MathAbs(m_confidence) < m_volume_threshold)
         return 0.0;
            
      return MathSign(m_confidence) * GetRiskFactor();
   }
   
   double MathSign(double value)
   {
      return value > 0 ? 1.0 : (value < 0 ? -1.0 : 0.0);
   }
   
   void SetLookbackPeriod(int period) 
   {
      m_lookback_period = MathMax(5, MathMin(100, period));
   }
   
   void SetVolumeThreshold(double threshold) 
   {
      m_volume_threshold = MathMax(0.5, MathMin(5.0, threshold));
   }

   // Quantum volume update
   void UpdateVolume()
   {
      // Quantum state preparation
      long volume[];
      ArrayResize(volume, 1);
      
      // Quantum volume measurement
      if(CopyTickVolume(m_symbol, m_timeframe, 0, 1, volume) > 0)
      {
         // Quantum state transformation
         m_quantum_state = (double)volume[0] / m_volume_threshold;
         
         // Quantum phase calculation
         double phase = MathArctan2(m_quantum_state, m_previous_volume);
         
         // Quantum coherence update
         m_quantum_coherence = MathCos(phase);
         
         // Quantum state preservation
         m_previous_volume = m_quantum_state;
      }
   }

   // Quantum volume signal calculation
   virtual double GetSignal() const
   {
      // Quantum state preparation
      double current_volume = m_quantum_state;
      double previous_volume = m_previous_volume;
      
      // Quantum phase calculation
      double phase = MathArctan2(current_volume, previous_volume);
      
      // Quantum volume surge calculation
      double surge = current_volume - previous_volume;
      
      // Quantum coherence factor
      double coherence = MathCos(phase);
      
      // Quantum signal generation
      double signal = surge * coherence;
      
      // Quantum state collapse
      return MathTanh(signal * m_quantum_coherence);
   }
};
//+------------------------------------------------------------------+
