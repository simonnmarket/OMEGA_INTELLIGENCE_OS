//+------------------------------------------------------------------+
//| MeanReversionAgent.mqh - Mean Reversion Trading Agent             |
//| Versão 3.0 - Corrigida e Completa                                |
//+------------------------------------------------------------------+
#property copyright "Copyright 2024, MetaQuotes Ltd."
#property link      "https://www.mql5.com"   
#property version   "1.00"
#property strict

#include "AgentBase.mqh"

class MeanReversionAgent : public AgentBase
{
private:
   int               m_lookback_period;
   double            m_deviation_threshold;
   
   // Método auxiliar para sinal matemático
   double MathSign(double value) const
   {
      return value > 0 ? 1.0 : (value < 0 ? -1.0 : 0.0);
   }

public:
   // Constructor
   MeanReversionAgent(string symbol, QuantumMarketPhysics* physics = NULL) : 
      AgentBase(symbol, physics, 10)  // Corrigido para usar valor inteiro válido
   {
      m_lookback_period = 20;
      m_deviation_threshold = 2.0;
      m_oversold = -2.0;
      m_overbought = 2.0;
   }
   
   // Implementação do método Update da classe base
   void Update() override
   {
      // Atualiza primeiro a classe base
      AgentBase::Update();
      
      // Obtenção dos handles dos indicadores
      int ma_handle = iMA(m_symbol, m_timeframe, m_lookback_period, 0, MODE_SMA, PRICE_CLOSE);
      int std_handle = iStdDev(m_symbol, m_timeframe, m_lookback_period, 0, MODE_SMA, PRICE_CLOSE);
      
      if(ma_handle == INVALID_HANDLE || std_handle == INVALID_HANDLE)
      {
         Print("Erro ao criar handles: MA=", ma_handle, " StdDev=", std_handle);
         if(ma_handle != INVALID_HANDLE) IndicatorRelease(ma_handle);
         if(std_handle != INVALID_HANDLE) IndicatorRelease(std_handle);
         return;
      }
      
      // Preparação dos arrays de dados
      double ma[1], std_dev[1], close[1];
      
      // Cópia dos dados
      bool success = CopyBuffer(ma_handle, 0, 0, 1, ma) > 0 &&
                    CopyBuffer(std_handle, 0, 0, 1, std_dev) > 0 &&
                    CopyClose(m_symbol, m_timeframe, 0, 1, close) > 0;
      
      // Liberação dos handles
      IndicatorRelease(ma_handle);
      IndicatorRelease(std_handle);
      
      if(!success)
      {
         Print("Erro ao copiar dados dos indicadores");
         return;
      }
      
      // Cálculo seguro com proteção contra divisão por zero
      double std_dev_value = std_dev[0] > 0 ? std_dev[0] : 1e-8;
      double current_confidence = (ma[0] - close[0]) / std_dev_value;
      
      // Atualiza confiança na classe base (suavizada com tanh)
      m_confidence = MathTanh(current_confidence);
   }
   
   // Quantum mean reversion signal calculation
   virtual double GetSignal() const
   {
      // Quantum state preparation
      double quantum_state = m_quantum_state;
      double mean_state = m_mean_state;
      
      // Quantum phase calculation
      double phase = MathArctan2(quantum_state, mean_state);
      
      // Quantum amplitude calculation
      double amplitude = MathAbs(quantum_state - mean_state);
      
      // Quantum coherence factor
      double coherence = MathCos(phase);
      
      // Quantum signal generation
      double signal = amplitude * coherence;
      
      // Quantum state collapse
      return MathTanh(signal * m_quantum_coherence);
   }
   
   // Métodos para configuração
   void SetLookbackPeriod(int period) 
   {
      m_lookback_period = MathMax(5, MathMin(200, period));
   }
   
   void SetDeviationThreshold(double threshold) 
   {
      m_deviation_threshold = MathMax(0.5, MathMin(5.0, threshold));
   }
};