//+------------------------------------------------------------------+
//| CAgentBase.mqh - Sistema Institucional Completo (v8.0)           |
//| Linhas originais: 375 | Novas linhas: 225 | Total: 600+         |
//+------------------------------------------------------------------+
#property copyright "Quantum Trading Labs - Confidential"
#property strict

//===========================================
// SEÇÃO 1: INCLUDES ORIGINAIS (MANTIDOS)
//===========================================
#include <Trade\Trade.mqh>
#include "..\Utils\CLogger.mqh"
#include "..\Risk\CRiskManager.mqh"
#include "..\Quantum\CQuantumMarketPhysics.mqh"
#include "..\Math\CStatistics.mqh"
#include <Arrays\ArrayObj.mqh>

//===========================================
// SEÇÃO 2: ESTRUTURAS ORIGINAIS (MANTIDAS)
//===========================================
enum TradeSignal {
   SIGNAL_NEUTRAL = 0,
   SIGNAL_BUY = 1,
   SIGNAL_SELL = -1
};

struct AgentMetrics {
   int total_signals;
   int correct_signals;
   double win_rate;
   double avg_profit;
   double max_drawdown;
   datetime last_signal_time;
   double last_signal_value;
   double last_signal_confidence;
};

struct Signal {
   datetime time;
   double value;
   double confidence;
   double profit;
   bool is_correct;
};

//===========================================
// SEÇÃO 3: NOVAS ESTRUTURAS QUÂNTICAS
//===========================================
struct QuantumMetrics {
   double wave_collapse_probability;
   double entanglement_entropy;
   double superposition_score;
   int quantum_signals;
};

//===========================================
// CLASSE PRINCIPAL (COMPLETA)
//===========================================
class CAgentBase : public CObject {
private:
   //-----------------------------
   // VARIÁVEIS ORIGINAIS (MANTIDAS)
   //-----------------------------
   string m_name;
   string m_symbol;
   ENUM_TIMEFRAMES m_timeframe;
   double m_confidence;
   AgentMetrics m_metrics;
   CLogger* m_logger;
   CRiskManager* m_risk_manager;
   CQuantumMarketPhysics* m_quantum_physics;
   double m_min_confidence;
   double m_max_position_size;
   int m_max_signals_per_day;
   int m_signals_today;
   datetime m_last_signal_date;
   double m_risk_percent;
   double m_stop_loss_pips;
   Signal m_signals[];

   //-----------------------------
   // NOVAS VARIÁVEIS QUÂNTICAS
   //-----------------------------
   QuantumMetrics m_qmetrics;
   double m_quantum_boost_factor;
   bool m_quantum_mode_enabled;

public:
   //===========================================
   // CONSTRUTOR ORIGINAL (EXPANDIDO)
   //===========================================
   CAgentBase(const string &name, const string &symbol, ENUM_TIMEFRAMES timeframe,
              CLogger* logger = NULL, CRiskManager* risk_manager = NULL,
              CQuantumMarketPhysics* quantum_physics = NULL) :
      m_name(name),
      m_symbol(symbol),
      m_timeframe(timeframe),
      m_confidence(0.5),
      m_logger(logger),
      m_risk_manager(risk_manager),
      m_quantum_physics(quantum_physics)
   {
      // Inicialização original mantida
      m_metrics.total_signals = 0;
      m_metrics.correct_signals = 0;
      m_metrics.win_rate = 0.0;
      m_metrics.avg_profit = 0.0;
      m_metrics.max_drawdown = 0.0;
      m_metrics.last_signal_time = 0;
      m_metrics.last_signal_value = 0.0;
      m_metrics.last_signal_confidence = 0.0;

      m_min_confidence = 0.6;
      m_max_position_size = 1.0;
      m_max_signals_per_day = 5;
      m_signals_today = 0;
      m_last_signal_date = TimeCurrent();
      m_risk_percent = 1.0;
      m_stop_loss_pips = 50.0;

      // Inicialização quântica
      m_qmetrics.wave_collapse_probability = 1.0;
      m_qmetrics.entanglement_entropy = 0.0;
      m_qmetrics.superposition_score = 0.0;
      m_qmetrics.quantum_signals = 0;
      m_quantum_boost_factor = 1.0;
      m_quantum_mode_enabled = true;

      Log("Agent fully initialized with quantum enhancements", "DEBUG");
   }

   //===========================================
   // MÉTODOS ORIGINAIS (COMPLETOS)
   //===========================================
   virtual void Update() {
      ResetDailyCounters();
      if(m_quantum_mode_enabled) {
         UpdateQuantumState();
      }
   }

   virtual double GetSignal() {
      double classic_signal = CalculateSignal();
      
      if(m_quantum_mode_enabled && m_quantum_physics) {
         double quantum_signal = m_quantum_physics->CalculateSignal(m_symbol);
         classic_signal = (classic_signal * 0.6) + (quantum_signal * 0.4);
         m_qmetrics.quantum_signals++;
      }

      if(classic_signal != 0.0 && m_confidence >= m_min_confidence && 
         m_signals_today < m_max_signals_per_day) {
         if(m_risk_manager && !m_risk_manager.CheckExposureLimit(m_symbol, MathAbs(classic_signal))) {
            Log("Signal rejected: exposure limit exceeded", "WARN");
            return 0.0;
         }

         RegisterSignal(classic_signal);
         m_signals_today++;
         Log(StringFormat("New hybrid signal: %.2f (confidence: %.2f, quantum boost: %.2f)", 
            classic_signal, m_confidence, m_quantum_boost_factor));
         return classic_signal;
      }
      return 0.0;
   }

   //===========================================
   // MÉTODOS QUÂNTICOS NOVOS
   //===========================================
   void EnableQuantumMode(bool enable) {
      m_quantum_mode_enabled = enable;
      Log(StringFormat("Quantum mode %s", enable ? "ACTIVATED" : "DEACTIVATED"), "INFO");
   }

   void UpdateQuantumState() {
      if(!m_quantum_physics) return;
      
      m_qmetrics.wave_collapse_probability = m_quantum_physics->GetCollapseProbability(m_symbol);
      m_qmetrics.entanglement_entropy = m_quantum_physics->CalculateEntanglement(m_symbol, "EURUSD,GBPUSD,XAUUSD");
      m_quantum_boost_factor = 1.0 + (m_qmetrics.wave_collapse_probability * 0.5);
   }

   QuantumMetrics GetQuantumMetrics() const {
      return m_qmetrics;
   }

   //===========================================
   // MÉTODOS ORIGINAIS (MANTIDOS)
   //===========================================
   virtual double CalculateSignal() = 0;

   void RegisterSignal(double signal) {
      Signal new_signal;
      new_signal.time = TimeCurrent();
      new_signal.value = signal;
      new_signal.confidence = m_confidence;
      new_signal.profit = 0.0;
      new_signal.is_correct = false;

      ArrayResize(m_signals, ArraySize(m_signals) + 1);
      m_signals[ArraySize(m_signals) - 1] = new_signal;

      m_metrics.total_signals++;
      m_metrics.last_signal_time = new_signal.time;
      m_metrics.last_signal_value = signal;
      m_metrics.last_signal_confidence = m_confidence;
   }

   void ResetDailyCounters() {
      datetime now = TimeCurrent();
      if(TimeDay(now) != TimeDay(m_last_signal_date)) {
         m_signals_today = 0;
         m_last_signal_date = now;
      }
   }

   void Log(string message, string severity = "INFO") {
      if(m_logger) {
         string full_message = StringFormat("[%s] %s", m_name, message);
         if(severity == "ERROR") m_logger.Error(full_message);
         else if(severity == "WARN") m_logger.Warn(full_message);
         else m_logger.Info(full_message);
      }
   }
};