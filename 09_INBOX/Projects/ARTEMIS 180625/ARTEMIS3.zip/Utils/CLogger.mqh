//+------------------------------------------------------------------+
//| CLogger.mqh - Institutional Logging System                       |
//+------------------------------------------------------------------+
#property copyright "Copyright 2025, MetaQuotes Ltd."
#property link      "https://www.quantumtrading.foundation" 
#property version   "1.0"
#property strict

#include <Trade\HistoryOrderInfo.mqh>
#include "..\Utils\WinInet.mqh"

class CLogger : public CObject {
private:
   string m_file;
   int m_min_level;
   bool m_console;
   bool m_file_output;
   bool m_web_output;
   string m_telegram_token;
   string m_telegram_chat_id;

public:
   // Constructor
   CLogger(string filename = "artemis.log", int level = LOG_LEVEL_INFO) {
      m_file = filename;
      m_min_level = level;
      m_console = true;
      m_file_output = true;
      m_web_output = false;
   }

   void SetConsoleOutput(bool enable) { m_console = enable; }
   void SetFileOutput(bool enable) { m_file_output = enable; }
   void SetTelegramSettings(string token, string chat_id) {
      m_telegram_token = token;
      m_telegram_chat_id = chat_id;
   }

   void Log(int level, string message) {
      if(level < m_min_level) return;

      string timestamp = TimeToString(TimeCurrent(), TIME_DATE|TIME_MINUTES|TIME_SECONDS);
      string full_message = StringFormat("%s [%s] %s", timestamp, LevelToString(level), message);

      if(m_console)
         Print(full_message);

      if(m_file_output)
         WriteToFile(full_message);

      if(m_web_output && !m_telegram_token.IsEmpty() && !m_telegram_chat_id.IsEmpty())
         SendTelegramMessage(full_message);
   }

   void Debug(string msg) { Log(LOG_LEVEL_DEBUG, msg); }
   void Info(string msg) { Log(LOG_LEVEL_INFO, msg); }
   void Warn(string msg) { Log(LOG_LEVEL_WARNING, msg); }
   void Error(string msg) { Log(LOG_LEVEL_ERROR, msg); }
   void Fatal(string msg) { Log(LOG_LEVEL_CRITICAL, msg); }

private:
   string LevelToString(int level) {
      switch(level) {
         case LOG_LEVEL_DEBUG: return "DEBUG";
         case LOG_LEVEL_INFO: return "INFO";
         case LOG_LEVEL_WARNING: return "WARN";
         case LOG_LEVEL_ERROR: return "ERROR";
         case LOG_LEVEL_CRITICAL: return "FATAL";
         default: return "UNKNOWN";
      }
   }

   void WriteToFile(string message) {
      int handle = FileOpen(m_file, FILE_WRITE|FILE_READ|FILE_TXT);
      if(handle != INVALID_HANDLE) {
         FileSeek(handle, 0, SEEK_END);
         FileWriteString(handle, message + "\n");
         FileClose(handle);
      }
   }

   void SendTelegramMessage(string message) {
      string url = StringFormat("https://api.telegram.org/bot%s/sendMessage",  m_telegram_token);
      string data = StringFormat("chat_id=%s&text=%s", m_telegram_chat_id, message);

      char result[];
      char data_array[];
      StringToCharArray(data, data_array);

      int res = WebRequest("POST", url, data_array, result, 10000);
      if(res == -1) {
         Print("Erro ao enviar mensagem para Telegram: ", GetLastError());
      }
   }
};