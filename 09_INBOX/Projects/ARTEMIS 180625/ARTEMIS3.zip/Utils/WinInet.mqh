//+------------------------------------------------------------------+
//| WinInet.mqh - Institutional Web Communication System             |
//| Version 1.0 - Unified and Enhanced (2025)                       |
//+------------------------------------------------------------------+
#property copyright "Copyright 2025, MetaQuotes Ltd."
#property link      "https://www.quantumtrading.foundation" 
#property version   "1.0"
#property strict

#include "..\Utils\CLogger.mqh"

class CWinInet {
public:
   // Método POST - envia dados via WebRequest
   static bool HttpPost(string url, string data, string &response, CLogger* logger = NULL) {
      if(url == "" || data == "") {
         if(logger != NULL)
            logger.Warn("Empty URL or data in HTTP POST request");
         else
            Print("[WinInet] Empty URL or data in HTTP POST request");
         return false;
      }

      char data_array[];
      StringToCharArray(data, data_array);

      char result[];
      int res = WebRequest("POST", url, NULL, NULL, 5000, data_array, result, NULL);

      if(res == 200) {
         response = CharArrayToString(result);
         if(logger != NULL)
            logger.Info(StringFormat("HTTP POST successful to %s", url));
         return true;
      } else {
         if(logger != NULL)
            logger.Error(StringFormat("HTTP POST failed with code %d to %s", res, url));
         else
            Print("[WinInet] HTTP POST failed with code ", res, " to ", url);
         return false;
      }
   }

   // Método GET - recebe dados via WebRequest
   static bool HttpGet(string url, string &response, CLogger* logger = NULL) {
      if(url == "") {
         if(logger != NULL)
            logger.Warn("Empty URL in HTTP GET request");
         else
            Print("[WinInet] Empty URL in HTTP GET request");
         return false;
      }

      char result[];
      int res = WebRequest("GET", url, NULL, NULL, 5000, NULL, result, NULL);

      if(res == 200) {
         response = CharArrayToString(result);
         if(logger != NULL)
            logger.Info(StringFormat("HTTP GET successful from %s", url));
         return true;
      } else {
         if(logger != NULL)
            logger.Error(StringFormat("HTTP GET failed with code %d from %s", res, url));
         else
            Print("[WinInet] HTTP GET failed with code ", res, " from ", url);
         return false;
      }
   }

   // Método PUT - atualização segura
   static bool HttpPut(string url, string data, string &response, CLogger* logger = NULL) {
      if(url == "" || data == "") {
         if(logger != NULL)
            logger.Warn("Empty URL or data in HTTP PUT request");
         else
            Print("[WinInet] Empty URL or data in HTTP PUT request");
         return false;
      }

      char data_array[];
      StringToCharArray(data, data_array);

      char headers[] = "X-HTTP-Method-Override: PUT";
      char result[];
      int res = WebRequest("POST", url, headers, NULL, 5000, data_array, result, NULL);

      if(res == 200) {
         response = CharArrayToString(result);
         if(logger != NULL)
            logger.Info(StringFormat("HTTP PUT successful to %s", url));
         return true;
      } else {
         if(logger != NULL)
            logger.Error(StringFormat("HTTP PUT failed with code %d to %s", res, url));
         else
            Print("[WinInet] HTTP PUT failed with code ", res, " to ", url);
         return false;
      }
   }

   // Método DELETE - exclusão remota
   static bool HttpDelete(string url, string &response, CLogger* logger = NULL) {
      if(url == "") {
         if(logger != NULL)
            logger.Warn("Empty URL in HTTP DELETE request");
         else
            Print("[WinInet] Empty URL in HTTP DELETE request");
         return false;
      }

      char headers[] = "X-HTTP-Method-Override: DELETE";
      char result[];
      int res = WebRequest("POST", url, headers, NULL, 5000, NULL, result, NULL);

      if(res == 200) {
         response = CharArrayToString(result);
         if(logger != NULL)
            logger.Info(StringFormat("HTTP DELETE successful to %s", url));
         return true;
      } else {
         if(logger != NULL)
            logger.Error(StringFormat("HTTP DELETE failed with code %d to %s", res, url));
         else
            Print("[WinInet] HTTP DELETE failed with code ", res, " to ", url);
         return false;
      }
   }

   // Validação de URL
   static bool ValidateURL(string url) {
      if(url == "") return false;
      if(StringFind(url, "http://") != 0 && StringFind(url, "https://")  != 0) return false;
      return true;
   }

   // Codificação de URL
   static string UrlEncode(string str) {
      string encoded = "";
      for(int i = 0; i < StringLen(str); i++) {
         char c = StringGetChar(str, i);
         if((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') ||
            c == '-' || c == '_' || c == '.' || c == '!' || c == '~' || c == '*' || c == '\'' || c == '(' || c == ')')
         {
            encoded += CharToString(c);
         }
         else if(c == ' ')
         {
            encoded += "+";
         }
         else
         {
            string hex = IntegerToHexString(c, 2);
            encoded += "%" + hex;
         }
      }
      return encoded;
   }

private:
   // Conversor interno
   static string IntegerToHexString(int number, int length = 0) {
      string hex = IntegerToString(number, 16);
      while(StringLen(hex) < length)
         hex = "0" + hex;
      return hex;
   }
};