//+------------------------------------------------------------------+
//| CStatistics.mqh - Institutional Statistical Analysis System        |
//| Version 1.0 - Unified and Enhanced (2025)                       |
//+------------------------------------------------------------------+
#property copyright "Copyright 2025, MetaQuotes Ltd."
#property link      "https://www.quantumtrading.foundation" 
#property version   "1.0"
#property strict

#include <Trade\HistoryOrderInfo.mqh>
#include "..\Utils\CLogger.mqh"

// Estrutura para métricas estatísticas
struct StatMetrics {
   double mean;
   double std_dev;
   double variance;
   double skewness;
   double kurtosis;
   datetime last_update;
};

class CStatistics : public CObject {
private:
   // Configurações internas
   int m_min_data_points;
   bool m_is_initialized;

   // Integração
   CLogger* m_logger;

public:
   // Constructor
   CStatistics(CLogger* logger = NULL) {
      m_min_data_points = 2;
      m_is_initialized = false;
      m_logger = logger;
   }

   // Destructor
   ~CStatistics() {}

   // Inicializa com símbolo e timeframe
   bool Initialize(string symbol, ENUM_TIMEFRAMES timeframe, int lookback = 20) {
      if(symbol == "" || timeframe <= 0 || lookback <= 0) return false;

      m_is_initialized = true;
      if(m_logger != NULL) m_logger.Info("CStatistics initialized");
      return true;
   }

   // Verifica se está inicializado
   bool IsInitialized() const { return m_is_initialized; }

   // Média simples
   static double Mean(const double &data[]) {
      if(ArraySize(data) < 2) return 0.0;
      double sum = 0.0;
      for(int i = 0; i < ArraySize(data); i++) {
         sum += data[i];
      }
      return sum / ArraySize(data);
   }

   // Desvio padrão amostral
   static double StandardDeviation(const double &data[]) {
      if(ArraySize(data) < 2) return 0.0;
      double mean = Mean(data);
      double sum = 0.0;

      for(int i = 0; i < ArraySize(data); i++) {
         sum += MathPow(data[i] - mean, 2);
      }

      return MathSqrt(sum / (ArraySize(data) - 1));
   }

   // Variância amostral
   static double Variance(const double &data[]) {
      if(ArraySize(data) < 2) return 0.0;
      double mean = Mean(data);
      double sum = 0.0;

      for(int i = 0; i < ArraySize(data); i++) {
         sum += MathPow(data[i] - mean, 2);
      }

      return sum / (ArraySize(data) - 1);
   }

   // Covariância entre duas séries
   static double Covariance(const double &data1[], const double &data2[]) {
      if(ArraySize(data1) != ArraySize(data2)) {
         Print("Erro: Tamanhos incompatíveis em covariância");
         return 0.0;
      }

      if(ArraySize(data1) < 2) return 0.0;

      double mean1 = Mean(data1);
      double mean2 = Mean(data2);
      double sum = 0.0;

      for(int i = 0; i < ArraySize(data1); i++) {
         sum += (data1[i] - mean1) * (data2[i] - mean2);
      }

      return sum / (ArraySize(data1) - 1);
   }

   // Coeficiente de correlação linear
   static double Correlation(const double &data1[], const double &data2[]) {
      double cov = Covariance(data1, data2);
      double std1 = StandardDeviation(data1);
      double std2 = StandardDeviation(data2);

      if(std1 == 0 || std2 == 0) return 0.0;
      return cov / (std1 * std2);
   }

   // Grau de assimetria na distribuição
   static double Skewness(const double &data[]) {
      if(ArraySize(data) < 2) return 0.0;
      double mean = Mean(data);
      double std = StandardDeviation(data);
      double sum = 0.0;

      for(int i = 0; i < ArraySize(data); i++) {
         sum += MathPow((data[i] - mean) / std, 3);
      }

      return sum / ArraySize(data);
   }

   // Grau de curtose (pico ou cauda pesada)
   static double Kurtosis(const double &data[]) {
      if(ArraySize(data) < 2) return 0.0;
      double mean = Mean(data);
      double std = StandardDeviation(data);
      double sum = 0.0;

      for(int i = 0; i < ArraySize(data); i++) {
         sum += MathPow((data[i] - mean) / std, 4);
      }

      return sum / ArraySize(data) - 3;
   }

   // Calcular percentil
   static double Percentile(const double &data[], double percentile) {
      if(percentile < 0 || percentile > 1) return 0.0;
      if(ArraySize(data) == 0) return 0.0;

      double sorted[];
      ArrayCopy(sorted, data);
      ArraySort(sorted);

      int index = (int)MathRound(ArraySize(sorted) * percentile);
      return sorted[index];
   }

   // Calcular mediana
   static double Median(const double &data[]) {
      return Percentile(data, 0.5);
   }

   // Calcular quartil
   static double Quartile(const double &data[], int quartile) {
      if(quartile < 1 || quartile > 3) return 0.0;
      return Percentile(data, quartile * 0.25);
   }

   // Calcular retorno diário médio
   double CalculateDailyReturn() {
      double equity[];
      HistorySelect(TimeCurrent() - 86400, TimeCurrent(), equity);
      if(ArraySize(equity) < 2) return 0.0;

      return (equity[0] - equity[1]) / equity[1];
   }

   // Calcular volatilidade histórica
   double CalculateHistoricalVolatility(int period = 20) {
      double prices[];
      int copied = CopyClose(Symbol(), PERIOD_M1, 0, period, prices);
      if(copied < 2) return 0.0;

      double returns[];
      ArrayResize(returns, period - 1);
      for(int i = 0; i < period - 1; i++) {
         returns[i] = (prices[i] - prices[i + 1]) / prices[i + 1];
      }

      return StandardDeviation(returns);
   }

   // Obter coeficiente de variação
   double CoefficientOfVariation(const double &data[]) {
      double mean = Mean(data);
      double std_dev = StandardDeviation(data);
      if(mean == 0) return 0.0;
      return std_dev / mean;
   }

   // Regressão linear simples
   bool LinearRegression(const double &x[], const double &y[], double &slope, double &intercept) {
      if(ArraySize(x) != ArraySize(y) || ArraySize(x) < 2) return false;

      double x_mean = Mean(x);
      double y_mean = Mean(y);
      double numerator = 0.0, denominator = 0.0;

      for(int i = 0; i < ArraySize(x); i++) {
         numerator += (x[i] - x_mean) * (y[i] - y_mean);
         denominator += MathPow(x[i] - x_mean, 2);
      }

      if(denominator == 0) return false;

      slope = numerator / denominator;
      intercept = y_mean - slope * x_mean;
      return true;
   }

   // Calcular R²
   double RSquared(const double &x[], const double &y[]) {
      double y_mean = Mean(y);
      double total_variance = 0.0, explained_variance = 0.0;
      double predicted[];
      ArrayResize(predicted, ArraySize(x));

      double slope, intercept;
      if(!LinearRegression(x, y, slope, intercept)) return 0.0;

      for(int i = 0; i < ArraySize(x); i++) {
         predicted[i] = slope * x[i] + intercept;
         total_variance += MathPow(y[i] - y_mean, 2);
         explained_variance += MathAbs(predicted[i] - y[i]);
      }

      return 1 - (explained_variance / total_variance);
   }

   // Calcular drawdown máximo
   double MaxDrawdown(const double &equity[]) {
      if(ArraySize(equity) < 2) return 0.0;

      double max_equity = equity[0];
      double max_drawdown = 0.0;

      for(int i = 1; i < ArraySize(equity); i++) {
         max_equity = MathMax(max_equity, equity[i]);
         double drawdown = (max_equity - equity[i]) / max_equity;
         max_drawdown = MathMax(max_drawdown, drawdown);
      }

      return max_drawdown;
   }

   // Calcular índice de Sharpe
   double SharpeRatio(const double &returns[], double risk_free_rate = 0.02) {
      if(ArraySize(returns) < 2) return 0.0;

      double mean_return = Mean(returns);
      double std_dev = StandardDeviation(returns);
      if(std_dev == 0) return 0.0;

      return (mean_return - risk_free_rate / 252) / std_dev * MathSqrt(252);
   }

   // Calcular Sortino Ratio
   double SortinoRatio(const double &returns[], double target_return = 0.02) {
      if(ArraySize(returns) < 2) return 0.0;

      double downside_returns[];
      int count = 0;

      for(int i = 0; i < ArraySize(returns); i++) {
         if(returns[i] < target_return / 252) {
            ArrayPush(downside_returns, returns[i]);
            count++;
         }
      }

      if(count == 0) return 0.0;

      double downside_std = StandardDeviation(downside_returns);
      double excess_return = Mean(returns) - target_return / 252;
      return excess_return / downside_std * MathSqrt(252);
   }

   // Calcular beta de mercado
   double MarketBeta(const double &asset_returns[], const double &market_returns[]) {
      if(ArraySize(asset_returns) != ArraySize(market_returns) || ArraySize(asset_returns) < 2) return 0.0;

      double covariance = Covariance(asset_returns, market_returns);
      double market_variance = Variance(market_returns);
      if(market_variance == 0) return 0.0;

      return covariance / market_variance;
   }

protected:
   // Carregar retornos diários
   int LoadDailyReturns(double &returns[], int period = 252) {
      double equity[];
      HistorySelect(TimeCurrent() - period * 86400, TimeCurrent(), equity);
      int size = ArraySize(equity);
      if(size < 2) return 0;

      ArrayResize(returns, size - 1);
      for(int i = 0; i < size - 1; i++)
         returns[i] = (equity[i] - equity[i + 1]) / equity[i + 1];

      return size - 1;
   }

   // Logging centralizado
   void Log(string message, string severity = "INFO") {
      if(m_logger != NULL) {
         string full_message = StringFormat("[%s] %s", "Statistics", message);
         if(severity == "ERROR")
            m_logger.Error(full_message);
         else if(severity == "WARN")
            m_logger.Warn(full_message);
         else
            m_logger.Info(full_message);
      } else {
         Print(message);
      }
   }

private:
   // Validar dados
   bool ValidateData(const double &data[], int min_size = 2) {
      if(ArraySize(data) < min_size) {
         Log("Dados insuficientes para análise estatística", "ERROR");
         return false;
      }
      return true;
   }
};