//+------------------------------------------------------------------+
//| GALEX.mq5 - Galactic Algorithmic Execution System                |
//| v3.0 - Sistema Multiagente Quântico com Execução Institucional   |
//+------------------------------------------------------------------+

#include <Trade\Trade.mqh>
#include <Math\Alglib\alglib.mqh>
#include <Genetic\GeneticAlgorithm.mqh>

// Núcleo do sistema
#include "Core/QuantumState.mqh"
#include "Core/MarketField.mqh"
#include "Core/DecisionMatrix.mqh"

// Agentes especializados
#include "Agents/AgentBase.mqh"
#include "Agents/MomentumAgent.mqh"
#include "Agents/MeanReversionAgent.mqh"
#include "Agents/VolumeSurgeAgent.mqh"

// Módulos avançados
#include "Risk/DynamicRiskManager.mqh"
#include "Risk/PortfolioBalancer.mqh"
#include "Interface/HUDManager.mqh"
#include "Trade/OrderLauncher.mqh"
#include "Math/QuantumMath.mqh"

input string Symbols = "EURUSD,GBPUSD,USDJPY,XAUUSD,BTCUSD";
input double BaseRiskPercent = 1.0;
input int MaxOrdersPerSymbol = 3;
input int MagicNumber = 20250601;
input bool UseVWAPExecution = true;
input bool UseTWAPExecution = false;
input double MaxSlippage = 3.0; // em pips
input double MaxMarketImpact = 0.5; // % do volume diário

// Variáveis globais
string symbols[];
int total_symbols;
CTrade trade;

// Instâncias dos módulos
DynamicRiskManager* risk_manager = NULL;
HUDManager* hud = NULL;
MarketField* market_field = NULL;
PortfolioBalancer* portfolio_balancer = NULL;
OrderLauncher* order_launcher = NULL;

AgentBase* agents[4];
DecisionMatrix* matrix = NULL;

//+------------------------------------------------------------------+
//| Função de inicialização do sistema                               |
//+------------------------------------------------------------------+
int OnInit()
{
   // Inicializa símbolos
   total_symbols = StringSplit(Symbols, ',', symbols);
   Print("Símbolos carregados: ", total_symbols);

   // Configura módulos principais
   risk_manager = new DynamicRiskManager(
      BaseRiskPercent,
      MaxOrdersPerSymbol,
      100, // TakeProfit padrão
      100, // StopLoss padrão
      true, // TrailingStop
      50,   // TrailingStart
      20,   // TrailingStep
      true, // Breakeven
      60    // BreakevenTrigger
   );

   market_field = new MarketField();
   portfolio_balancer = new PortfolioBalancer(market_field, BaseRiskPercent * 5);
   
   // Configura executores de ordem
   order_launcher = new OrderLauncher(MagicNumber, MaxSlippage, MaxMarketImpact);
   order_launcher.SetExecutionMethod(UseVWAPExecution, UseTWAPExecution);
   order_launcher.SetOrderSizeLimit(50.0); // Limite de 50 lotes por ordem

   // Inicializa agentes
   agents[0] = new MomentumAgent();
   agents[1] = new MeanReversionAgent();
   agents[2] = new VolumeSurgeAgent();
   agents[3] = new QuantumArbitrageAgent(); // Novo agente adicionado

   matrix = new DecisionMatrix();
   hud = new HUDManager(1024, 768); // Full HD

   // Configuração inicial completa
   EventSetTimer(10); // Atualização a cada 10 segundos
   market_field->AnalyzeAll(symbols, total_symbols);

   return INIT_SUCCEEDED;
}

//+------------------------------------------------------------------+
//| Função de desinicialização                                      |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   // Libera toda a memória alocada
   delete hud;
   delete risk_manager;
   delete market_field;
   delete portfolio_balancer;
   delete order_launcher;
   delete matrix;

   for(int i=0; i<4; i++)
      delete agents[i];

   EventKillTimer();
}

//+------------------------------------------------------------------+
//| Função principal de execução                                    |
//+------------------------------------------------------------------+
void OnTick()
{
   for(int i=0; i<total_symbols; i++)
   {
      string symbol = symbols[i];
      StringTrimLeft(symbol); StringTrimRight(symbol);
      if(!SymbolSelect(symbol, true)) continue;

      // 1. Atualização do campo de mercado
      market_field->Update(symbol, i);
      
      // 2. Análise dos agentes
      int signals[];
      ArrayResize(signals, 4);
      
      for(int j=0; j<4; j++) {
         if(agents[j] != NULL) {
            signals[j] = agents[j]->Analyze(symbol);
            Print("Agente ", agents[j]->Name(), " | Sinal para ", symbol, ": ", SignalToString(signals[j]));
         }
      }
      
      // 3. Decisão coletiva
      int final_signal = matrix->CollectiveDecision(agents, symbol);
      double confidence = matrix->GetDecisionConfidence();
      
      // 4. Gerenciamento de risco e execução
      if(final_signal != 0) {
         double sl_pips = risk_manager->CalculateDynamicSL(symbol);
         double tp_pips = risk_manager->CalculateDynamicTP(symbol, sl_pips);
         double lot_size = risk_manager->CalcLot(symbol, sl_pips, confidence);
         
         if(portfolio_balancer->CanOpenNewPosition(symbol, lot_size, symbols)) {
            double price = order_launcher->GetEntryPrice(symbol, final_signal);
            double sl = risk_manager->CalculateSL(symbol, price, final_signal, sl_pips);
            double tp = risk_manager->CalculateTP(symbol, price, final_signal, tp_pips);
            
            if(order_launcher->SendOrder(symbol, final_signal, lot_size, price, sl, tp, "GALEX v3.0")) {
               Print("Ordem executada para ", symbol, " | Ticket: ", order_launcher->GetLastOrderTicket());
            }
         }
      }
      
      // 5. Atualização da interface
      string status = market_field->GetStatus(i);
      QuantumState state = market_field->GetQuantumState(i);
      hud->Update(symbol, final_signal, status, state);
      
      // 6. Gerenciamento de posições abertas
      risk_manager->ManagePositions(symbol, trade, MagicNumber);
   }
   
   // Rebalanceamento periódico do portfólio
   static datetime last_rebalance = 0;
   if(TimeCurrent() - last_rebalance >= 3600) { // A cada hora
      portfolio_balancer->QuantumRebalance(symbols, total_symbols);
      last_rebalance = TimeCurrent();
   }
}

//+------------------------------------------------------------------+
//| Função de timer para tarefas assíncronas                        |
//+------------------------------------------------------------------+
void OnTimer()
{
   // Atualização do campo de mercado completo
   market_field->AnalyzeAll(symbols, total_symbols);
   
   // Verificação de risco do portfólio
   if(portfolio_balancer->GetValueAtRisk() > 25.0) {
      Alert("ALERTA: VaR do portfólio acima de 25% - ", portfolio_balancer->GetValueAtRisk());
   }
   
   // Atualização do HUD
   hud->Refresh();
}

//+------------------------------------------------------------------+
//| Funções auxiliares                                              |
//+------------------------------------------------------------------+
string SignalToString(int signal) {
   switch(signal) {
      case 1: return "🟢 Compra Forte";
      case -1: return "🔴 Venda Forte";
      case 2: return "🟡 Compra Fraca";
      case -2: return "🟠 Venda Fraca";
      default: return "⚪ Neutro";
   }
}

//+------------------------------------------------------------------+
//| Função para fechamento emergencial                              |
//+------------------------------------------------------------------+
void EmergencyCloseAll()
{
   for(int i=PositionsTotal()-1; i>=0; i--)
   {
      if(PositionGetInteger(POSITION_MAGIC) == MagicNumber)
      {
         order_launcher->ClosePositionsSmart(PositionGetString(POSITION_SYMBOL));
      }
   }
}